//
//  GroupBookingViewModel.swift
//  RestaurantApp
//
//  Created by MAC on 17/05/2024.
//

import Foundation
import Firebase

class GroupBookingViewModel: ObservableObject {
    @Published var groupBooking: [GroupBookingModel] = []
    @Published var errorMessage: String? = nil
    @Published var success = false
    let db = Firestore.firestore()
    
    func saveData(groupBookingData: GroupBookingModel, completion: @escaping (Result<Void, Error>) -> Void) {
        
        let groupBookingDict: [String: Any] = [
            "id": groupBookingData.id ,
            "userId": groupBookingData.userId,
            "tableId": groupBookingData.tableId,
            "date": groupBookingData.date,
            "time": groupBookingData.time,
            "numberOfPeople": groupBookingData.numberOfPeople,
            "setMenu": groupBookingData.setMenu,
            "specialArrangement": groupBookingData.specialArrangement ?? ""
        ]
        
        db.collection("groupBookings").document(groupBookingData.id).setData(groupBookingDict) { error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(()))
                self.success = true
            }
        }
    }
    
    func fetchGroupBookings(for userId: String) {
            db.collection("groupBookings").whereField("userId", isEqualTo: userId)
                .addSnapshotListener { (querySnapshot, error) in
                    guard let documents = querySnapshot?.documents else {
                        return
                    }
                    
                    self.groupBooking = documents.map({ queryDocumentSnapshot -> GroupBookingModel in
                        let data = queryDocumentSnapshot.data()
                        
                        let id = data["id"] as? String ?? ""
                        let date = data["date"] as? String ?? ""
                        let time = data["time"] as? String ?? ""
                        let numberOfPeople = data["numberOfPeople"] as? Int ?? 0
                        let setMneu = data["setMenu"] as? String ?? ""
                        let specialarrangments = data["specialArrangement"] as? String ?? ""
                        
                        print("result", GroupBookingModel(id: id, userId: Auth.auth().currentUser?.uid ?? "", tableId: "", date: date, time: time, numberOfPeople: numberOfPeople, setMenu: setMneu, specialArrangement: specialarrangments))
                        
                        return GroupBookingModel(id: id, userId: Auth.auth().currentUser?.uid ?? "", tableId: "", date: date, time: time, numberOfPeople: numberOfPeople, setMenu: setMneu, specialArrangement: specialarrangments)
                        
                    })
                }
        }
    
    func deleteReservation(reservationId: String, completion: @escaping (Result<Void, Error>) -> Void) {
            db.collection("groupBookings").document(reservationId).delete { error in
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.success(()))
                }
            }
        }
}

//
//  EventBookingModel.swift
//  RestaurantApp
//
//  Created by MAC on 16/05/2024.
//

import SwiftUI

struct EventBookingModel {
    let id: String
    let userId: String
    let eventName: String
    let numberOfTickets: Int
    let specialRequest: String
}

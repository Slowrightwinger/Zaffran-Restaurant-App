//
//  LoginVIew.swift
//  RestaurantApp
//
//  Created by MAC on 15/05/2024.
//

import SwiftUI

struct SignInView: View {
    @EnvironmentObject var viewModel: AuthenticationViewModel
    @State var email = ""
    @State var password = ""
    
    var body: some View {
            VStack {
                TextField("Email Address", text: $email)
                    .disableAutocorrection(false)
                    .autocapitalization(.none)
                    .padding()
                    .background(Color.white)
                    .shadow(radius: 5)
                    .padding(.bottom)
                SecureField("Password", text: $password)
                    .disableAutocorrection(false)
                    .autocapitalization(.none)
                    .padding()
                    .background(Color.white)
                    .shadow(radius: 5)
                Button(action: {
                    guard !email.isEmpty, !password.isEmpty else {
                        return
                    }
                    viewModel.signedIn = true
                    viewModel.SignIn(email: email, password: password)
                }, label: {
                    Text("Sign IN")
                        .foregroundColor(.white)
                        .frame(width: 200, height: 50, alignment: .center)
                        .background(Color.blue)
                        .cornerRadius(10)
                })
                .padding()
                .alert(isPresented: $viewModel.signedIn) {
                    Alert(title: Text("Success"), message: Text("Loggen in successfully"))
                }
                NavigationLink("Create Account", destination: SignUpView())
                .padding()
            }
            .padding()
            .navigationTitle("Sign In")
    }
}

#Preview {
    SignInView()
}

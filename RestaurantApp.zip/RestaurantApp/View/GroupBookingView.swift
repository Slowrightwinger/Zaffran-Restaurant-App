//
//  GroupBookingView.swift
//  RestaurantApp
//
//  Created by MAC on 15/05/2024.
//

import SwiftUI
import Firebase

struct GroupBookingView: View {
    @State private var selectedDate = Date()
    @State private var selectedTime = Date()
    @State private var numberOfPeople = 1
    @State private var setMenu = ""
    @State private var specialArrangements = ""
    @StateObject var viewModel = GroupBookingViewModel()
    var menu = ["Arabic Food", "Chinese Food", "Indian Food", "Italian Food", "Thai Food"]
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Group Booking")
                .font(.largeTitle)
                .padding()
            
            DatePicker("Select Date", selection: $selectedDate, displayedComponents: .date)
                .padding()
            
            DatePicker(selection: $selectedTime, displayedComponents: .hourAndMinute) {
                Text("Select Time")
            }
            
            Stepper(value: $numberOfPeople, in: 1...100) {
                Text("Number of People: \(numberOfPeople)")
            }
            .padding()
            
            Picker("selectTable", selection: $setMenu) {
                ForEach(menu, id: \.self) { table in
                    Text(table)
                }
            }
            .pickerStyle(MenuPickerStyle())
            .tint(Color.black)
            .padding(.horizontal)
            .padding(.vertical, 10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .overlay {
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.gray.opacity(0.6))
            }
            
            TextField("Special Arrangements", text: $specialArrangements)
                .padding()
                .overlay {
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray.opacity(0.6))
                }
            
            Button(action: {
                saveGroupBooking()
            }) {
                Text("Book Group")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding()
            .alert(isPresented: $viewModel.success) {
                Alert(title: Text("success"), message: Text("booking confirmed"))
            }
            
            Spacer()
        }
        .padding()
    }
    
    private func saveGroupBooking() {
        let booking = GroupBookingModel(id: UUID().uuidString, userId: Auth.auth().currentUser?.uid ?? "", tableId: "", date: DateFormatter.localizedString(from: selectedDate, dateStyle: .none, timeStyle: .short), time: DateFormatter.localizedString(from: selectedTime, dateStyle: .none, timeStyle: .short), numberOfPeople: numberOfPeople, setMenu: setMenu, specialArrangement: specialArrangements)
        print("Booking Data", booking)
        
        viewModel.saveData(groupBookingData: booking) { result in
            switch result {
            case .success():
                print("booking saved successfully")
            case .failure(let error):
                print("Error saving bookings: \(error.localizedDescription)")
            }
        }
    }
}

#Preview {
    GroupBookingView()
}

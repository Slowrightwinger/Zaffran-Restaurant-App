//
//  AuthenticationViewModel.swift
//  RestaurantApp
//
//  Created by MAC on 15/05/2024.
//

import SwiftUI
import FirebaseAuth

class AuthenticationViewModel: ObservableObject {
    let auth = Auth.auth()
    @Published var signedIn = false
    @Published var signup = false
    var isSignedIn: Bool {
        return auth.currentUser != nil
    }
    
    func SignIn(email: String, password: String) {
        auth.signIn(withEmail: email, password: password) { [weak self] (result, error) in
            guard result != nil, error == nil else {
                return
            }
            DispatchQueue.main.async {
                self?.signedIn = true
            }
        }
    }
    
    func SignUp(email: String, password: String) {
        auth.createUser(withEmail: email, password: password) { [weak self]  (result, error) in
            guard result != nil, error == nil else {
                return
            }
            // sucess
            DispatchQueue.main.async {
                self?.signedIn = true
                self?.signup = true
            }
        }
    }
    
    func SignOut() {
        try? auth.signOut()
        self.signedIn = false
    }
    
}

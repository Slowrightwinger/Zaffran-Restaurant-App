//
//  SignUpView.swift
//  RestaurantApp
//
//  Created by MAC on 15/05/2024.
//

import SwiftUI

struct SignUpView: View {
    @StateObject var viewModel = AuthenticationViewModel()
    @State var email = ""
    @State var password = ""
    @State var confirmPassword = ""
    @State var showAlert = false
    @State var alertMessage = ""
    
    var body: some View {
        VStack(spacing: 14) {
                TextField("Email Address", text: $email)
                    .disableAutocorrection(false)
                    .autocapitalization(.none)
                    .padding()
                    .background(Color.white)
                    .shadow(radius: 5)
                SecureField("Password", text: $password)
                    .disableAutocorrection(false)
                    .autocapitalization(.none)
                    .padding()
                    .background(Color.white)
                    .shadow(radius: 5)
                SecureField("Confirm Password", text: $confirmPassword)
                    .disableAutocorrection(false)
                    .autocapitalization(.none)
                    .padding()
                    .background(Color.white)
                    .shadow(radius: 5)
                Button(action: {
                    guard !email.isEmpty, !password.isEmpty, password != confirmPassword else {
                        return
                    }
                    
                    if password != confirmPassword {
                        alertMessage = "Passwords do not match"
                        showAlert = true
                    }
                    viewModel.SignUp(email: email, password: password)
                }, label: {
                    Text("Sign Up")
                        .foregroundColor(.white)
                        .frame(width: 200, height: 50, alignment: .center)
                        .background(Color.blue)
                        .cornerRadius(10)
                })
                .padding()
                .alert(isPresented: $viewModel.signup) {
                    Alert(title: Text("Success"), message: Text("Your account is created now login"))
                }
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("Error"), message: Text(alertMessage))
                }
            }
            .padding()
            .navigationTitle("Create Account")
    }
}

#Preview {
    SignUpView()
}
